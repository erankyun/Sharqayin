SHARQAYIN — VERSION 1.000

Armenian variable typeface by Hamlet Petrosyan.

Variable axis: wght 400–900
Named instances: Regular, Medium, Semi Bold, Bold, Extra Bold, Black

Variable-TT/      variable TrueType font
OpenType-TT/       static TrueType styles
OpenType-PS/       static OpenType PS styles
WOFF2/             static webfont styles
specimen/          specimen image
OFL.txt            SIL Open Font License 1.1
FONTLOG.txt        release history

The fonts are licensed under the SIL Open Font License 1.1.
